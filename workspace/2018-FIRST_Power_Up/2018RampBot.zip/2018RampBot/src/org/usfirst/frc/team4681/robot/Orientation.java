package org.usfirst.frc.team4681.robot;

public enum Orientation {
	Forward,
	Backward,
	Left,
	Right //LOOKING OUT FROM THE DRIVING STATION
}
